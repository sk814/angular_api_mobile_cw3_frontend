from django.apps import AppConfig


class MycovtesthubappConfig(AppConfig):
    name = 'mycovtesthubapp'
