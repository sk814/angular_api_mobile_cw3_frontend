from django.apps import AppConfig


class VirustestingappConfig(AppConfig):
    name = 'virusTestingApp'
