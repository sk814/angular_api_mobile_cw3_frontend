from django.apps import AppConfig


class MycovtesthubapplicationConfig(AppConfig):
    name = 'MyCoVTestHubApplication'
