###run command(in project folder)- python3 manage.py runserver
###username- admin
###pasword- 1234
###admin link- http://localhost:8000/dashboard/virusTestingApp/registereduser/
