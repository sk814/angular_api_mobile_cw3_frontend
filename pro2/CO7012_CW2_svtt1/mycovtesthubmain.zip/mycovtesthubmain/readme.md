### python3 manage.py runserver
###FORM URL: http://localhost:8000/home
### DASHBOARD URL: http://localhost:8000/admin/mycovtesthubapp/testform/
***
####login: admin
####password: 12345
***
